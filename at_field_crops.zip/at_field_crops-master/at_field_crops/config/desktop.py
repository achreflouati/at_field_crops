# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from frappe import _

def get_data():
	return [
		{
			"module_name": "Crops",
			"color": "#000000",
			"icon": "assets/at_field_crops/images/aticonwhite.svg",
			"type": "module",
			"label": _("Crops")
		}
	]

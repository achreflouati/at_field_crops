// Copyright (c) 2017, AgriTheory and contributors
// For license information, please see license.txt

frappe.ui.form.on('Crop Variety', {
	refresh: function(frm) {

	}
});
